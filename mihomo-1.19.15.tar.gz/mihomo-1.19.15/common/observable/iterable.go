package observable

type Iterable[T any] <-chan T
