//go:build !with_gvisor

package features

const WithGVisor = false
