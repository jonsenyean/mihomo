package sing_tun

const supportRedirect = true
