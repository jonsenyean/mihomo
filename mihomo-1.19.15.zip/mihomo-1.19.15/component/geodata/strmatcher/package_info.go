// Modified from: https://github.com/v2fly/v2ray-core/tree/master/common/strmatcher
// License: MIT

package strmatcher
