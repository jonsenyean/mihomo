//go:build no_fake_tcp

package features

const NoFakeTCP = true
