//go:build !linux

package sing_tun

const supportRedirect = false
