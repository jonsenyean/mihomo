//go:build cmfa

package features

const CMFA = true
